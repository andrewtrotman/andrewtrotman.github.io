/*
	COMPRESS_INTEGER_ELIAS_DELTA.H
	------------------------------
	Copyright (c) 2018 Andrew Trotman
	Released under the 2-clause BSD license (See:https://en.wikipedia.org/wiki/BSD_licenses)
*/
/*!
	@file
	@brief Elias delta compression
	@author Andrew Trotman
	@copyright 2018 Andrew Trotman
*/
#pragma once

#include <stdint.h>
#include <immintrin.h>


#include "maths.h"

namespace JASS
	{
	/*
		CLASS COMPRESS_INTEGER_ELIAS_DELTA
		----------------------------------
	*/
	/*!
		@brief Elias delta encoding of integers
		@details
		See: A. Trotman, K. Lilly (2018) Elias Revisited: Group Elias SIMD Coding, in Proceedings of ADCS 2018.

		To quote the Wikipedia (https://en.wikipedia.org/wiki/Elias_delta_coding):

		To code a number X ≥ 1:
			Let N = floor(log2 X) be the highest power of 2 in X, so 2^N ≤ X < 2^(N+1).
			Let L = floor(log2 N+1) be the highest power of 2 in N+1, so 2^L ≤ N+1 < 2^(L+1).
			Write L zeros, followed by
			the L+1-bit binary representation of N+1, followed by
			all but the leading bit (i.e. the last N bits) of X.
		An equivalent way to express the same process:
			Separate X into the highest power of 2 it contains (2^N) and the remaining N binary digits.
			Encode N+1 with Elias gamma coding.
			Append the remaining N binary digits to this representation of N+1.

		See:  P. Elias (1975). "Universal codeword sets and representations of the integers". IEEE Transactions on Information Theory. 21 (2): 194–203. doi:10.1109/tit.1975.1055349.
	*/
	class compress_integer_elias_delta
		{
		public:
			/*
				COMPRESS_INTEGER_ELIAS_DELTA::ENCODE()
				--------------------------------------
			*/
			/*!
				@brief Encode a sequence of integers returning the number of bytes used for the encoding, or 0 if the encoded sequence doesn't fit in the buffer.
				@param encoded_as_void [out] The sequence of bytes that is the encoded sequence.
				@param encoded_buffer_length [in] The length (in bytes) of the output buffer, encoded.
				@param source [in] The sequence of integers to encode.
				@param source_integers [in] The length (in integers) of the source buffer.
				@return The number of bytes used to encode the integer sequence, or 0 on error (i.e. overflow).
			*/
			size_t encode(void *encoded_as_void, size_t encoded_buffer_length, const uint32_t *source, size_t source_integers)
				{
				uint8_t *encoded = static_cast<uint8_t *>(encoded_as_void);

				/*
					Zero the destination array
				*/
				memset(encoded, 0, encoded_buffer_length);

				/*
					encode
				*/
				uint64_t into = 0;									// bit position to write into (counted from the beginning of encoded).
				for (const uint32_t *value = source; value < source + source_integers; value++)
					{
					/*
						Get the length
					*/
					uint32_t n = maths::floor_log2(*value) + 1;

					/*
						Get the unary part of the length.  The binary part is already stored in n
					*/
					uint32_t unary = maths::floor_log2(n);


					/*
						Write unary numner of 0-bits (no write necessary as the bits are already 0).
					*/
					into += unary;

					/*
						Move the high bit of the integer to the low bit so that we can use that bit as the end of the unary
						This is because we rely on storing the data from the low end of the integer to the high end so that we can dip in at any byte
						and have the correct sequence of bits.  It also means we can return the size used in bytes rather than as 32-bit integers (so we
						can truncate the byte sequence at any point).  It also appears to reduce the complexity of decoding.
					*/
					uint64_t zig_zag = ((n & ~(1 << unary)) << 1) + 1;

					/*
						Append the value in binary
					*/
					size_t shift = into % 8;
					uint64_t pattern = zig_zag << shift;
					uint64_t *address = reinterpret_cast<uint64_t *>(encoded + (into / 8));
					*address |= pattern;

					into += unary + 1;

					/*
						We now know the length of the integer so we can encode the actual value in binary (without zig-zagging) with the high bit turned off
					*/
					shift = into % 8;
					pattern = (*value & ~(1ULL << (n - 1))) << shift;
					address = reinterpret_cast<uint64_t *>(encoded + (into / 8));
					*address |= pattern;

					into += n - 1;
					}

				return ((into + 7) / 8);
				}
			/*
				COMPRESS_INTEGER_ELIAS_DELTA::DECODE()
				--------------------------------------
			*/
			/*!
				@brief Decode a sequence of integers encoded with this codex.
				@param decoded [out] The sequence of decoded integers.
				@param integers_to_decode [in] The minimum number of integers to decode (it may decode more).
				@param source_as_void [in] The encoded integers.
				@param source_length [in] The length (in bytes) of the source buffer.
			*/
			void decode(uint32_t *decoded, size_t integers_to_decode, const void *source_as_void, size_t source_length)
				{
				const uint64_t *source = reinterpret_cast<const uint64_t *>(source_as_void);
				uint64_t value = 0;
				uint8_t unary;
				uint8_t binary;
				int8_t bits_used;		/// bits used in the second word if we cross a word boundary (and not kept from block to block)
				int8_t bits_remaining = 0;

				for (uint32_t *end = decoded + integers_to_decode; decoded < end; decoded++)
					{
					/*
						get the width of the width
					*/
					if (value != 0)
						{
						unary = (uint8_t)_tzcnt_u64(value);
						value >>= unary;
						bits_remaining -= unary;
						}
					else
						{
						/*
							The unary part splits a machine word
						*/
						value = *source++;
						bits_used = (uint8_t)_tzcnt_u64(value);
						unary = bits_remaining + bits_used;
						value >>= bits_used;
						bits_remaining = 64 - bits_used;
						}

					/*
						get the zig-zag encoded length of the integer and un-zig-zag it.
					*/
					if (bits_remaining - unary > 0)
						{
						binary = (uint8_t)((_bextr_u64(value, 0, unary + 1) >> 1)) | (1 << unary);		// un-zig-zag
						bits_remaining -= unary + 1;
						value >>= unary + 1;
						}
					else
						{
						/*
							The binary splits a machine word
						*/
						binary = (uint8_t)value;
						value = *source++;
						binary |= (uint8_t)(_bextr_u64(value, 0, unary - bits_remaining + 1) << bits_remaining);
						binary = (binary >> 1) | (1UL << unary);				// un-zig-zag
						bits_used = unary - bits_remaining + 1;
						bits_remaining = 64 - bits_used;
						value >>= bits_used;
						}

					/*
						get the binary value that is encoded using elias delta
					*/
					if (bits_remaining - binary >= 0)
						{
						*decoded = (uint32_t)(_bextr_u64(value, 0, binary)) | (1 << (binary - 1));
						bits_remaining -= binary - 1;
						value >>= binary - 1;
						}
					else
						{
						/*
							the encoded number splits a machine word
						*/
						*decoded = (uint32_t)value | (1 << (binary - 1));
						value = *source++;
						*decoded |= (_bextr_u64(value, 0, binary - bits_remaining) << bits_remaining);
						bits_used = binary - bits_remaining - 1;
						bits_remaining = 64 - bits_used;
						value >>= bits_used;
						}
					}
				}
		};
	}
