/*
	MATHS.H
	-------
	Copyright (c) 2016 Andrew Trotman
	Released under the 2-clause BSD license (See:https://en.wikipedia.org/wiki/BSD_licenses)
*/
/*!
	@file
	@brief Basic maths functions.
	@details Some of these already exist in the C++ Standard Library or the C Runtime Library, but they are re-implemented here for portabilit and consistency reasons.
	@author Andrew Trotman
	@copyright 2016 Andrew Trotman
*/
#pragma once

#include <stdio.h>
#include <stdint.h>

#include <limits>
#include <type_traits>

namespace JASS
	{
	/*
		MATHS_CEILING_LOG2_ANSWER[]
		---------------------------
	*/
	/*!
		@brief Lookup table to compute ceil(log2(x))
	*/
	static constexpr uint8_t maths_ceiling_log2_answer[0x100] =
		{
		0, 1, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4,
		5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
		6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
		6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
		7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
		7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
		7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
		7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
		8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
		8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
		8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
		8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
		8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
		8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
		8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
		8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8
		};

	/*
		MATHS_FLOOR_LOG2_ANSWER[]
		-------------------------
	*/
	/*!
		@brief Lookup table to compute flooe(log2(x))
	*/
	static constexpr uint8_t maths_floor_log2_answer [0x100] =
		{
		0, 0, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3,
		4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4,
		5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
		5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
		6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
		6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
		6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
		6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
		7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
		7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
		7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
		7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
		7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
		7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
		7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
		7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7
		};
		
	/*
		CLASS MATHS
		-----------
	*/
	/*!
		@brief Basic maths functions.
	*/
	class maths
		{
		public:
			/*
				MATHS()
				-------
			*/
			/*!
				@brief Constructor.
			*/
			maths() = delete;

			/*
				MATHS::MAXIMUM()
				----------------
			*/
			/*!
				@brief Return the maximum of the two parameters.
				@details This method is order-preserving - that is, if a == b then a is returned as the max.  This method is not called max to avoid macro substitution issues.
				@param first [in] First of the two.
				@param second [in] Second of the two.
				@return The largest of the two (as compated using operator>=())
			*/
			template <typename TYPE>
			static const TYPE &maximum(const TYPE &first, const TYPE &second)
				{
				return first >= second ? first : second;
				}

			/*
				MATHS::FLOOR_LOG2()
				-------------------
			*/
			/*!
				@brief return the floor of log2(x)
				@param x [in] the value to compute the log of.
				@return floor(log2(x));
			*/
			template <typename TYPE>
			static constexpr TYPE floor_log2(TYPE x)
				{
				/* coverity[BAD_SHIFT] */
				/* coverity[CONSTANT_EXPRESSION_RESULT] */
				return (static_cast<size_t>(x) >> 8 == 0) ?
				   maths_floor_log2_answer[x] :
				(static_cast<size_t>(x) >> 16 == 0) ?
					maths_floor_log2_answer[(static_cast<size_t>(x) >> 8) & 0xFF] + 8 :
				(static_cast<size_t>(x) >> 24 == 0) ?
					maths_floor_log2_answer[(static_cast<size_t>(x) >> 16) & 0xFF] + 16 :
				(static_cast<size_t>(x) >> 32 == 0) ?
					maths_floor_log2_answer[(static_cast<size_t>(x) >> 24) & 0xFF] + 24 :
				(static_cast<size_t>(x) >> 40 == 0) ?
					maths_floor_log2_answer[(static_cast<size_t>(x) >> 32) & 0xFF] + 32 :
				(static_cast<size_t>(x) >> 48 == 0) ?
					maths_floor_log2_answer[(static_cast<size_t>(x) >> 40) & 0xFF] + 40 :
				(static_cast<size_t>(x) >> 56 == 0) ?
					maths_floor_log2_answer[(static_cast<size_t>(x) >> 48) & 0xFF] + 48 :
					maths_floor_log2_answer[(static_cast<size_t>(x) >> 56) & 0xFF] + 56;
				}

			/*
				MATHS::CEILING_LOG2()
				---------------------
			*/
			/*!
				@brief return the ceiling of log2(x)
				@param x [in] the value to compute the log of.
				@return ceiling(log2(x));
			*/
			template <typename TYPE>
			static constexpr TYPE ceiling_log2(TYPE x)
				{
				/* coverity[BAD_SHIFT] */
				/* coverity[CONSTANT_EXPRESSION_RESULT] */
				return (static_cast<size_t>(x) >> 8 == 0) ?
				   maths_ceiling_log2_answer[x] :
				(static_cast<size_t>(x) >> 16 == 0) ?
					maths_ceiling_log2_answer[(static_cast<size_t>(x) >> 8) & 0xFF] + 8 :
				(static_cast<size_t>(x) >> 24 == 0) ?
					maths_ceiling_log2_answer[(static_cast<size_t>(x) >> 16) & 0xFF] + 16 :
				(static_cast<size_t>(x) >> 32 == 0) ?
					maths_ceiling_log2_answer[(static_cast<size_t>(x) >> 24) & 0xFF] + 24 :
				(static_cast<size_t>(x) >> 40 == 0) ?
					maths_ceiling_log2_answer[(static_cast<size_t>(x) >> 32) & 0xFF] + 32 :
				(static_cast<size_t>(x) >> 48 == 0) ?
					maths_ceiling_log2_answer[(static_cast<size_t>(x) >> 40) & 0xFF] + 40 :
				(static_cast<size_t>(x) >> 56 == 0) ?
					maths_ceiling_log2_answer[(static_cast<size_t>(x) >> 48) & 0xFF] + 48 :
					maths_ceiling_log2_answer[(static_cast<size_t>(x) >> 56) & 0xFF] + 56;
				}
		};
	}


