/*
	COMPRESS_INTEGER_ELIAS_GAMMA.H
	------------------------------
	Copyright (c) 2018 Andrew Trotman
	Released under the 2-clause BSD license (See:https://en.wikipedia.org/wiki/BSD_licenses)
*/
/*!
	@file
	@brief Elias gamma compression
	@author Andrew Trotman
	@copyright 2018 Andrew Trotman
*/
#pragma once

#include <stdint.h>

namespace JASS
	{
	/*
		CLASS COMPRESS_INTEGER_ELIAS_GAMMA
		----------------------------------
	*/
	/*!
		@brief Elias gamma encoding of integers
		@details  To quote the Wikipedia (https://en.wikipedia.org/wiki/Elias_gamma_coding):

		To code a number x ≥ 1:
			Let N = floor(log2(x)) be the highest power of 2 it contains, so 2^N ≤ x < 2^(N+1).
			Write out N zero bits, then
			Append the binary form of x, an (N + 1)-bit binary number.
		An equivalent way to express the same process:
			Encode N in unary; that is, as N zeroes followed by a one.
			Append the remaining N binary digits of x to this representation of N.

		To represent a number x Elias gamma uses 2 * floor(log2(x)) + 1 bits.

		See:  P. Elias (1975). "Universal codeword sets and representations of the integers". IEEE Transactions on Information Theory. 21 (2): 194–203. doi:10.1109/tit.1975.1055349.
	*/
	class compress_integer_elias_gamma
		{
		public:
			/*
				COMPRESS_INTEGER_ELIAS_GAMMA::ENCODE()
				--------------------------------------
			*/
			/*!
				@brief Encode a sequence of integers returning the number of bytes used for the encoding, or 0 if the encoded sequence doesn't fit in the buffer.
				@param encoded_as_void [out] The sequence of bytes that is the encoded sequence.
				@param encoded_buffer_length [in] The length (in bytes) of the output buffer, encoded.
				@param source [in] The sequence of integers to encode.
				@param source_integers [in] The length (in integers) of the source buffer.
				@return The number of bytes used to encode the integer sequence, or 0 on error (i.e. overflow).
			*/
			size_t encode(void *encoded_as_void, size_t encoded_buffer_length, const uint32_t *source, size_t source_integers)
				{
				uint8_t *encoded = static_cast<uint8_t *>(encoded_as_void);

				/*
					zero the destination array
				*/
				memset(encoded, 0, encoded_buffer_length);

				/*
					encode
				*/
				uint64_t into = 0;									// bit position to write into (counted from the beginning of encoded).
				for (const uint32_t *value = source; value < source + source_integers; value++)
					{
					/*
						Get the unary part
					*/
					uint32_t n = maths::floor_log2(*value);

					/*
						Write n 0-bits (no write necessary as the bits are already 0).
					*/
					into += n;

					/*
						Move the high bit of the integer to the low bit so that we can use that bit as the end of the unary
						This is because we rely on storing the data from the low end of the integer to the high end so that we can dip in at any byte
						and have the correct sequence of bits.  It also means we can return the size used in bytes rather than as 32-bit integers (so we
						can truncate the byte sequence at any point).  It also appears to reduce the complexity of decoding.
					*/
					uint64_t zig_zag = ((*value & ~(1 << n)) << 1) + 1;

					/*
						Append the value in binary
					*/
					size_t shift = into % 8;
					uint64_t pattern = zig_zag << shift;
					uint64_t *address = reinterpret_cast<uint64_t *>(encoded + (into / 8));
					*address |= pattern;
					into += n + 1;
					}

				return ((into + 7) / 8);
				}

			/*
				COMPRESS_INTEGER_ELIAS_GAMMA::DECODE()
				--------------------------------------
			*/
			/*!
				@brief Decode a sequence of integers encoded with this codex.
				@param decoded [out] The sequence of decoded integers.
				@param integers_to_decode [in] The minimum number of integers to decode (it may decode more).
				@param source_as_void [in] The encoded integers.
				@param source_length [in] The length (in bytes) of the source buffer.
			*/
			void decode(uint32_t *decoded, size_t integers_to_decode, const void *source_as_void, size_t source_length)
				{
				const uint64_t *source = reinterpret_cast<const uint64_t *>(source_as_void);
				uint64_t value = 0;
				uint8_t bits_used = 0;
				uint8_t bits_remaining = 0;
				uint8_t unary;

				for (uint32_t *end = decoded + integers_to_decode; decoded < end; decoded++)
					{
					/*
						get the width
					*/
					if (value != 0)
						{
						unary = (uint8_t)_tzcnt_u64(value);
						value >>= unary;
						bits_remaining -= unary;
						}
					else
						{
						/*
							the length splits a machine word
						*/
						unary = bits_remaining;
						value = *source++;
						bits_used = (uint8_t)_tzcnt_u64(value);
						unary += bits_used;
						value >>= bits_used;
						bits_remaining = 64 - bits_used;
						}

					/*
						get the zig-zag encoded binary, unzig-zag it and store it
					*/
					if (bits_remaining > unary)
						{
						*decoded = (uint32_t)((_bextr_u64(value, 0, unary + 1) >> 1)) | (1UL << unary);
						bits_remaining -= unary + 1;
						value >>= unary + 1;
						}
					else
						{
						/*
							the encoded number splits a machine word
						*/
						*decoded = (uint32_t)value;
						value = *source++;
						*decoded |= (uint32_t)((_bextr_u64(value, 0, unary - bits_remaining + 1)) << bits_remaining);
						*decoded = (*decoded >> 1) | (1UL << unary);				// unzig-zag
						bits_used = unary - bits_remaining + 1;
						bits_remaining = 64 - bits_used;
						value >>= bits_used;
						}
					}
				}
		};
	}
