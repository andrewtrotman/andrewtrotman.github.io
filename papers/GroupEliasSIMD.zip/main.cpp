/*
	MAIN.CPP
	--------
	Copyright (c) 2016 Andrew Trotman
	Released under the 2-clause BSD license (See:https://en.wikipedia.org/wiki/BSD_licenses)

	Test the BMI verison of Elias gamma and Elias delta and the and SIMD versions of group Elias gamma and group Elias delta.
*/
#include <vector>
#include <iostream>

#include "compress_integer_elias_delta.h"
#include "compress_integer_elias_delta_simd.h"
#include "compress_integer_elias_gamma.h"
#include "compress_integer_elias_gamma_simd.h"

/*
	SEQUENCE1
	---------
*/
std::vector<uint32_t> sequence1 =
	{
	1, 2, 3, 2, 1, 1, 2, 1, 3, 1, 1, 1, 2,
	2, 1, 2, 2, 2, 3, 1, 1, 1, 3, 6, 4, 1,
	2, 1, 1, 3, 1, 1, 1, 2, 1, 1, 1, 7, 7,
	1, 3, 11, 3, 3, 1, 2, 3, 3, 1, 3, 1, 1,
	2, 1, 1, 2, 1, 1, 2, 2, 1, 1, 4, 3, 6,
	1, 3, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1,
	1, 3, 6, 4, 1, 2, 1, 2, 1, 1, 3, 1, 1, 1,
	2, 1, 1, 1, 3, 1, 1, 1, 3, 2, 1, 1, 3, 1,
	1, 1, 3, 1, 3, 1, 2, 1, 1, 5, 1, 1, 2, 1,
	1, 1, 1, 3, 2, 4, 2, 1, 1, 6, 2, 1, 4, 1,
	1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 1,
	3, 1, 1, 1, 1, 1, 7, 1, 4, 30, 1, 1, 1, 2,
	2, 4, 2, 5, 2, 7, 4, 3, 4, 1, 2, 1, 1, 1, 2,
	4, 1, 2, 1, 2, 7, 1, 1, 3, 1, 5, 7, 4, 5, 1,
	1, 5, 1, 7, 6, 3, 4, 1, 4, 2, 1, 2, 3, 1, 2,
	1, 4, 3, 5, 1, 3, 1, 1, 1, 2, 1, 5, 1, 2, 1,
	1, 2, 3, 3, 4, 1, 1, 2, 2, 1, 1, 3, 5, 10, 3,
	2, 3, 7, 1, 1, 8, 1, 12, 2, 5, 3, 2, 4, 1, 3,
	3, 2, 1, 3, 1, 3, 1, 2, 1, 22, 3, 9, 12, 3, 7,
	1, 5, 4, 2, 16, 2, 2, 8, 4, 2, 4, 3, 2, 3, 6,
	1, 6, 1, 7, 29, 3, 6, 1, 6, 37, 17, 1, 1, 1,
	43, 127, 9, 31, 6, 23, 9, 5, 156, 19, 3, 16,
	1534, 19, 13, 15, 14, 65, 12, 9, 8, 1, 1, 4,
	1, 1, 1, 5, 33, 36, 66, 7, 2, 11, 2, 34, 13, 2,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 4, 1, 1, 1, 1, 1, 1, 4, 4, 1,
	5, 15, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 2, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1,
	1, 1, 1, 2, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1,
	2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 35, 1, 1,
	3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1,
	1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 2, 1, 46, 2, 1, 1, 2, 1,
	1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1,
	5, 1, 1, 1, 1, 1, 1, 2, 1, 2, 1, 1, 1, 2, 1, 1, 1,
	2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2, 2, 1, 1, 3, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1,
	1, 1, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 2, 3, 1, 1, 1, 1, 4, 2, 1, 1, 1, 1, 1, 2, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 7, 1, 1, 1,
	1, 2, 4, 2, 1, 1, 1, 44, 1, 1, 1, 1, 1, 1, 1, 2, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 2, 1, 1, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1,
	2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1,
	2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2,
	1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2,
	1, 1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 4, 1, 1, 1, 1,
	1, 1, 2, 1, 1, 1, 1, 41, 3228, 1, 1, 1, 1, 1, 1, 1,
	 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2,
	 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1,
	 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1,
	 1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1,
	 1, 1, 1, 1, 1, 1, 2, 1, 2, 1, 1, 1, 1, 1, 3, 2, 1,
	 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1};

/*
	SEQUENCE2
	---------
*/
std::vector<uint32_t> sequence2 =
	{
	6,10,2,1,2,1,1,1,1,2,2,1,1,14,1,1,		// 4 bits
	4,1,2,1,2,5,3,4,3,1,3,4,2,3,1,1,			// 3 bits
	6,13,5,1,2,8,4,2,5,1,1,1,2,1,1,2,		// 4 bits
	3,1,2,1,1,2,2,1,3,1,1,1,1,1,1,1,			// 2 bits
	1,2,1,1,1,1,1,1,2,1,1,1,1,1,2,3,			// 2 bits
	1,7,1,4,5,3,2,1,10,1,8,1,2,5,1,24,		// 5 bits
	1,1,1,1,1,1,1,5,5,2,2,1,3,4,5,5,			// 3 bits
	2,4,2,2,1,1,1,2,2,1,2,1,2,1,3,3,			// 3 bits
	3,7,3,2,1,1,4,5,4,1,4,8,6,1,2,1,			// 4 bits
	1,1,1,1,1,3,1,2,1,1,1,1,1,1,1,2,			// 2 bits						// 160 integers (1 complete AVX-512 word).

	1,3,2,2,3,1,2,1,1,2,1,1,1,1,1,2,			// 2 bits
	9,1,1,4,5,6,1,4,2,5,4,6,7,1,1,2,			// 4 bits
	1,1,9,2,2,1,2,1,1,1,1,1,1,1,1,1,			// 4 bits
	1,1,1,1,1,1,1,6,4,1,5,7,1,1,1,1,			// 3 bits
	2,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,			// 2 bits
	1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,1,			// 2 bits
	2,1,1,1,2,2,1,4,1,1,4,1,1,1,1,1,			// 3 bits
	1,1,1,1,1,2,5,3,1,3,1,1,4,1,2,1,			// 3 bits
	3,1,3,1,1,1,1,1,1,1,1,1,1,1,1,1,			// 2 bits						// 304 integers
	1,1,1,1,1,2,2,1,1,1,8,3,1,2,56,2,		// 6 bits						// 320 integers

	12,1,6,70,68,25,13,44,36,22,4,95,19,5,39,8, // 7 bits
	25,14,9,8,27,6,1,1,8,11,8,3,4,1,2,8,			// 5 bits
	3,23,2,16,8,2,28,26,6,11,9,16,1,1,7,7,			// 5 bits
	45,2,33,39,20,14,2,1,8,26,1,10,12,3,16,3,		// 6 bits
	25,9,6,9,6,3,41,17,15,11,33,8,1,1,1,1			// 6 bits
	};

/*
	SEQUENCE3
	---------
*/
std::vector<uint32_t> sequence3 =
	{
	1, 1, 1, 793, 1, 1, 1, 1, 2, 1, 5, 3, 2, 1, 5, 63,		// 10 bits
	1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 5, 6, 2, 4, 1, 2,			// 3 bits
	1, 1, 1, 1, 4, 2, 1, 2, 2, 1, 1, 1, 3, 2, 2, 1,			// 3 bits
	1, 1, 2, 3, 1, 1, 8, 1, 1, 21, 2, 9, 15, 27, 7, 4,		// 5 bits
	2, 7, 1, 1, 2, 1, 1, 3, 2, 3, 1, 3, 3, 1, 2, 2,			// 3 bits
	3, 1, 3, 1, 2, 1, 2, 4, 1, 1, 3, 10, 1, 2, 1, 1,		// 4 bits
	6, 2, 1, 1, 3, 3, 7, 3, 2, 1, 2, 4, 3, 1, 2, 1,			// 3 bits <31 bits>, carryover 1 from next line
	6, 2, 2, 1															// 3 bits
	};

/*
	SEQUENCE4
	---------
*/
std::vector<uint32_t> sequence4 =
	{
	1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3,
	1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3
	};

/*
	JASS_ASSERT()
	-------------
	A vesion fo assert() that works in debug builds.
*/
#define JASS_assert(expression) ((expression) ? ((void)0) : fail(__func__, __FILE__, __LINE__, #expression))

/*
	FAIL()
	------
	print a message stating where the program failed (i.e. asserted) and then terminate.
*/
	void fail(const char *function, const char *file, size_t line, const char *expression)
		{
		fprintf(stderr, "%s:%llu:%s: JASS_assertion \"%s\" failed", file, (unsigned long long)line, function, expression);
		abort();
		}

/*
	UNITTEST()
	----------
	Test one sequence on one codec.
*/
template <typename codec>
void unittest(const std::vector<uint32_t> &sequence)
	{
	codec coder;
	std::vector<uint8_t> buffer(sequence.size() * sizeof(uint32_t) * 2);	// this should be large enough as its twice the size of the raw buffer
	std::vector<uint32_t> into(sequence.size() + 1024);						// add space at the end as the decoders will decode in whole blocks and this can lead to overflow of a exact sized output buffer.

	auto encoded_length = coder.encode(&buffer[0], buffer.size(), &sequence[0], sequence.size());
	coder.decode(&into[0], sequence.size(), &buffer[0], encoded_length);

	into.resize(sequence.size());				// set the size of the output buffer to the correct size to remove any overflow from the end.

	JASS_assert(into == sequence);
	}

/*
	UNITTEST_SET()
	--------------
	Test a set of sequences on one codec.
*/
template <typename codec>
void unittest_set(const std::string &codec_name)
	{
	unittest<codec>(sequence1);
	unittest<codec>(sequence2);
	unittest<codec>(sequence3);
	unittest<codec>(sequence4);

	std::cout << codec_name << ": PASSED" << std::endl;
	}

/*
	MAIN()
	------
	Test each of the codecs in this release of the code base.
*/
int main(int argc, char *argv[])
	{
	unittest_set<JASS::compress_integer_elias_delta>("JASS::compress_integer_elias_delta");
	unittest_set<JASS::compress_integer_elias_delta_simd>("JASS::compress_integer_elias_delta_simd");
	unittest_set<JASS::compress_integer_elias_gamma>("JASS::compress_integer_elias_gamma");
	unittest_set<JASS::compress_integer_elias_gamma_simd>("JASS::compress_integer_elias_gamma_simd");

	return 0;
	}
