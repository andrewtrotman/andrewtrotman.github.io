/*
	SAA5050_FONT.H
	--------------
*/
#ifndef SAA5050_FONT_H_
#define SAA5050_FONT_H_

extern unsigned char saa5050_font[];

#endif /* SAA5050_FONT_H_ */
