/*
	SPEAKER.H
	---------
*/
#ifndef SPEAKER_H_
#define SPEAKER_H_

#include <windows.h>

/*
	class SPEAKER
	-------------
*/
class speaker
{
private:
	long frequency;
	double angle;
	long buffer_size;
	unsigned char *buffer;
	HINSTANCE hInstance;
	HWAVEOUT hWaveOut;
	WAVEHDR header;

protected:
	void fill_buffer(unsigned char *buffer);

public:
	speaker();
	virtual ~speaker();
	void play(long frequency);
	void quiet(void);
	void reset(void) { quiet(); }
} ;

#endif /* SPEAKER_H_ */

