/*
	PROTEUS_UNIT.H
	--------------
*/
#ifndef PROTEUS_UNIT_H_
#define PROTEUS_UNIT_H_

#include <windows.h>
#include "proteus.h"

/*
	class PROTEUS_UNIT
	------------------
*/
class proteus_unit
{
public:
	enum { ACTIVE, PASSIVE };

private:
	proteus *server;
	long mode;
	HINSTANCE hInstance;
	HBITMAP bmp_about;
	HBITMAP bmp_proteus;
	HWND window;

	long bmp_about_width, bmp_about_height;
	long bmp_proteus_width, bmp_proteus_height;

public:
	proteus_unit(HINSTANCE hInstance);
	virtual ~proteus_unit();

	static void load_disk(proteus *server, HWND hwnd, long menu);
	unsigned char *load_rom(long menu);

	BOOL about_box(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
	LRESULT windows_callback(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	proteus *create_window(char *window_title, long mode = ACTIVE);
} ;

#endif /* PROTEUS_UNIT_H_ */
