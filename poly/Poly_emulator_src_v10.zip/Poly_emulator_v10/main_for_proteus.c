/*
	MAIN.C
	------
*/
#include <windows.h>
#include "proteus_unit.h"

/*
	WINMAIN()
	---------
*/
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
MSG msg;
long done;
proteus_unit *server;

server = new proteus_unit(hInstance);
server->create_window("Proteus Computer");

done = false;
while(!done)
	{
	PeekMessage(&msg, 0, NULL, NULL, PM_NOREMOVE);		// peek but don't remove the message from the queue (that happens below)
	if (msg.message == WM_QUIT)
		done = true;
	else
		{
		GetMessage(&msg, NULL, 0, 0);
		TranslateMessage(&msg);
		DispatchMessage(&msg);
		}
	}

return msg.wParam;
}
