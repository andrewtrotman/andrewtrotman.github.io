/*
	POLY_UNIT.H
	-----------
*/
#ifndef POLY_UNIT_H_
#define POLY_UNIT_H_

#include <windows.h>
#include "poly.h"
#include "proteus_unit.h"

/*
	class POLY_UNIT
	---------------
*/
class poly_unit
{
friend static LRESULT CALLBACK windows_callback(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

public:
	enum { ACTIVE, PASSIVE };

private:
	static const long WIDTH_IN_PIXELS = 480;
	static const long HEIGHT_IN_PIXELS = 240;
	static const long TIMER_TEXT_FLASH = 1;
	static const long TIMER_CPU_TICK = 2;
	static const long TIMER_DISPLAY_REFRESH = 4;

private:
	HINSTANCE hInstance;
	poly *client;
	HDC bitmap;
	unsigned char *canvas;
	HBITMAP bmp_about;
	long bmp_about_width, bmp_about_height;
  
	unsigned char poly_key_line_insert, poly_key_char_insert, poly_key_line_del, poly_key_char_del, poly_key_calc, poly_key_help;
	unsigned char poly_key_exit, poly_key_back, poly_key_repeat, poly_key_next, poly_key_pause, poly_key_left, poly_key_right;
	unsigned char poly_key_up, poly_key_down, poly_key_u0, poly_key_u1, poly_key_u2, poly_key_u3, poly_key_u4, poly_key_u5, poly_key_u6;
	unsigned char poly_key_u7, poly_key_u8, poly_key_u9, poly_key_at, poly_key_bar, poly_key_exp, poly_key_pound, poly_key_shift_pause;
	unsigned char poly_key_keypad_dot;

	long shift;

public:
	HWND window;

private:
	void make_canvas(void);
	LRESULT windows_callback(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	void set_keyboard_scan_codes(long poly_type);
	unsigned char translate_key(WPARAM wParam);
	proteus *server;
	poly **clients;
	long text_flash_state;

protected:
	void menu(WORD clicked);
	void set_rom_version(WORD option);
	void load_disk(HWND hwnd, long menu);

public:
	poly_unit(HINSTANCE hInstance, proteus *server = NULL, poly **clients = NULL);
	virtual ~poly_unit() {}

	BOOL about_box(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
	long create_window(char *window_title, long mode = ACTIVE);
	poly *connect_to(proteus *server);
	poly *connect_to(poly *downstream);
} ;

#endif /* POLY_UNIT_H_ */
